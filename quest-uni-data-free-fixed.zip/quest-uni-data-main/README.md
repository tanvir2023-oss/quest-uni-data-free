# Eduvanta University Intelligence — Free Stack

A full-stack TanStack Start application for researching **official university admissions information**: entry requirements, English tests, tuition, deadlines, programmes, faculties, documents, scholarships and more.

## No paid service is required

The project has been cleaned so it does **not depend on Lovable Cloud or Firecrawl**.

| Part | Service | Free option |
|---|---|---|
| Web app + server | Cloudflare Workers | Workers Free |
| Database + authentication | Supabase | Supabase Free |
| AI extraction + university-name discovery | Google Gemini API | Gemini 2.5 Flash-Lite free tier |
| Website crawling | Built-in HTTP/sitemap crawler | No crawling API |
| Source code | GitHub | Free |

Free means **within the providers' current free quotas**. It is not unlimited. Supabase Free can pause inactive projects, Cloudflare Workers Free has request/CPU limits, and Gemini has rate limits.

## 1. Local setup

Requirements: **Node.js 20+** and npm.

```bash
npm install
cp .env.example .env
npm run dev
```

Put these values in `.env`:

```text
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
GEMINI_MODEL=gemini-2.5-flash-lite
```

The `VITE_` values are the same public Supabase URL/key and are safe to expose in the browser. **Never put a Supabase service-role/secret key in the browser.**

## 2. Create the free Supabase database

1. Create a Supabase project on the Free plan.
2. Open **SQL Editor**.
3. Run the SQL files in `supabase/migrations/` in filename order.
4. In Authentication, keep Email/Password enabled if you want normal email login.
5. Google login is optional. If enabled, configure the Google provider in Supabase and add your deployed callback URL.

The database tables use Row Level Security so each authenticated user can access only their own research records.

## 3. Create the free Gemini key

Create a Gemini API key in Google AI Studio and put it in `GEMINI_API_KEY`.

The default model is:

```text
gemini-2.5-flash-lite
```

The app uses Gemini for structured extraction and, when the user gives only a university name, Google Search grounding to identify the official university domain. If the free quota is reached, the application reports the rate limit instead of silently switching to a paid provider.

For the safest zero-cost setup, **do not enable paid billing for the Gemini project/key**.

## 4. Deploy to Cloudflare Workers Free

Install/authenticate Wrangler:

```bash
npx wrangler login
```

Before building, make sure the following are available to the build/runtime environment:

```text
SUPABASE_URL
SUPABASE_PUBLISHABLE_KEY
VITE_SUPABASE_URL
VITE_SUPABASE_PUBLISHABLE_KEY
GEMINI_API_KEY
GEMINI_MODEL=gemini-2.5-flash-lite
```

Then:

```bash
npm run build
npx wrangler deploy
```

For a Git-based Cloudflare deployment, add the same variables in the Cloudflare project's build/runtime environment. The `VITE_*` variables must be available **during the Vite build** because the public Supabase configuration is embedded in the browser bundle.

## 5. What was removed/replaced

- Lovable Cloud dependency removed from the architecture.
- Firecrawl dependency replaced with direct HTTP fetching, sitemap discovery and same-domain link discovery.
- AI extraction uses Gemini directly instead of a paid AI connector.
- Supabase remains because its Free plan supplies both PostgreSQL and authentication without requiring a paid database service.
- No API key is committed to the repository.

## Research workflow

1. Create a research file with university name or official URL.
2. Discover official pages.
3. Crawl the selected official pages.
4. Run extraction for the required sections.
5. Review source URLs and verification status.
6. Print/export the selected research topics.

### Important crawling limitation

The built-in crawler uses ordinary HTTP requests. University websites that require heavy client-side JavaScript, bot protection or a browser session may not expose all content to it. When possible, enter the university's official URL directly; this avoids unnecessary website-discovery requests.

## Security

- `.env` and `.dev.vars` are ignored by Git.
- Only `.env.example` is intended to be committed.
- Never commit Gemini keys, Supabase secret/service-role keys or user credentials.
- If a secret was previously committed to GitHub, rotate it before deploying this version.
