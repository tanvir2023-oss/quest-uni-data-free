-- profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email TEXT,
  full_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name'))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- research projects
CREATE TABLE public.research_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  university_name TEXT NOT NULL,
  university_url TEXT,
  country TEXT NOT NULL,
  student_nationality TEXT NOT NULL,
  study_level TEXT NOT NULL,
  intake TEXT,
  subject TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  progress_note TEXT,
  official_domain TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.research_projects TO authenticated;
GRANT ALL ON public.research_projects TO service_role;
ALTER TABLE public.research_projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own research" ON public.research_projects FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_research_updated BEFORE UPDATE ON public.research_projects
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- source pages
CREATE TABLE public.source_pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  research_id UUID NOT NULL REFERENCES public.research_projects ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  url TEXT NOT NULL,
  title TEXT,
  category TEXT,
  is_official BOOLEAN NOT NULL DEFAULT true,
  content TEXT,
  fetched_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.source_pages TO authenticated;
GRANT ALL ON public.source_pages TO service_role;
ALTER TABLE public.source_pages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own source pages" ON public.source_pages FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_source_pages_research ON public.source_pages(research_id);

-- university profile
CREATE TABLE public.university_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  research_id UUID NOT NULL UNIQUE REFERENCES public.research_projects ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  data JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.university_profiles TO authenticated;
GRANT ALL ON public.university_profiles TO service_role;
ALTER TABLE public.university_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own university profile" ON public.university_profiles FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_uniprofile_updated BEFORE UPDATE ON public.university_profiles
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- faculties
CREATE TABLE public.faculties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  research_id UUID NOT NULL REFERENCES public.research_projects ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  name TEXT NOT NULL,
  kind TEXT,
  departments TEXT[] NOT NULL DEFAULT '{}',
  source_url TEXT,
  source_title TEXT,
  status TEXT NOT NULL DEFAULT 'confirmed',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.faculties TO authenticated;
GRANT ALL ON public.faculties TO service_role;
ALTER TABLE public.faculties ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own faculties" ON public.faculties FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_faculties_research ON public.faculties(research_id);

-- programmes
CREATE TABLE public.programmes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  research_id UUID NOT NULL REFERENCES public.research_projects ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  name TEXT NOT NULL,
  level TEXT,
  faculty TEXT,
  department TEXT,
  campus TEXT,
  study_mode TEXT,
  duration TEXT,
  credits TEXT,
  language TEXT,
  intakes TEXT,
  application_deadline TEXT,
  next_intake TEXT,
  start_date TEXT,
  tuition_fee TEXT,
  application_fee TEXT,
  deposit TEXT,
  other_fees TEXT,
  scholarships TEXT,
  admission_requirements TEXT,
  english_requirements TEXT,
  required_documents TEXT,
  programme_specific_requirements TEXT,
  source_url TEXT,
  source_title TEXT,
  status TEXT NOT NULL DEFAULT 'needs_verification',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.programmes TO authenticated;
GRANT ALL ON public.programmes TO service_role;
ALTER TABLE public.programmes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own programmes" ON public.programmes FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_programmes_research ON public.programmes(research_id);

-- data points
CREATE TABLE public.data_points (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  research_id UUID NOT NULL REFERENCES public.research_projects ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  section TEXT NOT NULL,
  subsection TEXT,
  label TEXT NOT NULL,
  value TEXT,
  detail TEXT,
  source_url TEXT,
  source_title TEXT,
  status TEXT NOT NULL DEFAULT 'needs_verification',
  is_official BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  checked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.data_points TO authenticated;
GRANT ALL ON public.data_points TO service_role;
ALTER TABLE public.data_points ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own data points" ON public.data_points FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_data_points_research ON public.data_points(research_id, section);